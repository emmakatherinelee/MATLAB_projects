function out = DrawWireframe (fv)
% Draw the object as a wireframe
out = patch (fv, 'FaceColor', 'none');